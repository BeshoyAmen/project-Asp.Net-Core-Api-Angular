using System.Threading.Tasks;
using core.Model.cart;
namespace core.interfaces
{
    public interface IBaskectRepositery
    {
         Task<StoreId> GetBasketAsync(string basketId);
         Task<StoreId> UpdateBasketAsync(StoreId basket);
         Task<bool> DeleteBasketAsync(string basketId);
        //  Task<cartShop> SearchKeys(cartShop basket);

        //  Task<IReadOnlyList<IActionResult>> AllbasketById();
        //  Task<int> CountAsycTable(string id);

    }
}