using System.Text.Json;
using core.interfaces;
using StackExchange.Redis;
using System;
using core.Model.cart;
using core.Model;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace Infrastructore.Data
{
    public class BasketRepositry:IBaskectRepositery
    {
        public readonly IDatabase _database; 
        // private readonly IRedisCacheClient _redisCacheClient;

        public BasketRepositry(IConnectionMultiplexer redis)
        {
            _database = redis.GetDatabase();
        }
      public async Task<StoreId> GetBasketAsync(string basketId)
      {
            var data= await _database.StringGetAsync(basketId.ToString());
            return data.IsNullOrEmpty ? null: JsonSerializer.Deserialize<StoreId>(data);
      }
        public async  Task<StoreId> UpdateBasketAsync(StoreId basket)
        {
            var create=await _database.StringSetAsync(basket.Id.ToString(),JsonSerializer.Serialize(basket),TimeSpan.FromDays(30));
            if(!create) return null;
            return await GetBasketAsync(basket.Id.ToString());
        }
        public async Task<bool> DeleteBasketAsync(string basketId)
         {
             return await _database.KeyDeleteAsync(basketId);
         }
    }
}