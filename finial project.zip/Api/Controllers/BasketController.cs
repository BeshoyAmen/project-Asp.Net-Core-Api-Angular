using System.Drawing;
using System.Dynamic;
using System.Security.Cryptography.X509Certificates;
using System.Reflection.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Api.DtoCartViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Infrastructore.Data;
using core.Model;
using core.Model.cart;
using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
using core.Model.Identity;
using core.interfaces;
using Infrastructore.Repositery;
using Api.Dtos;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Api.Extensions;
using Infrastructore.Data.Identity;
namespace Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BasketController : ControllerBase
    {
        // private readonly IBaskectRepositery _basket;
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;
        private readonly ItokenServices _tokenServices;
        private readonly IProductRepositery _repoproduct;
        private readonly IMapper _mapper;
        private readonly dataContext _context;


        public BasketController(dataContext context,IMapper mapper,IProductRepositery repoproduct,UserManager<AppUser> userManager,
        ItokenServices tokenServices,SignInManager<AppUser> signInManager )
        {
            _context=context;
            _mapper=mapper;
            _repoproduct=repoproduct;
            // _basket = basket;
            _userManager=userManager;
            _signInManager=signInManager;
            _tokenServices=tokenServices;
        }

        // GET: api/Basket/countBasket
        [HttpGet("countBasket")]
        [Authorize]
        public async Task<ActionResult<cartShop>> GetBasketCountForUser()
        {
          var user=await _userManager.FindByEmailFromClaimsPrinciple(HttpContext.User);
            var countUser= _context.cartShops.Where(ww=>ww.UserEamil ==user.Email).Count();
           if (countUser != 0)
           {
            return Ok(countUser);
           }
            return Ok("basket empty");
        }
        //All backet for user
    //post: api/Basket/
        [Authorize]
    [HttpPost]
    public async Task<ActionResult<cartShopDto>> proBasket(cartShop basket)
    {
        if(ModelState.IsValid)
        {
            basket.Id=0;
            var user=await _userManager.FindByEmailFromClaimsPrinciple(HttpContext.User);
                basket.UserEamil=user.Email;
                var shopdb=_context.cartShops.Where(x=> x.IDProduct==basket.IDProduct && x.UserEamil ==basket.UserEamil ).FirstOrDefault();
                if (shopdb == null)
                {
                    _context.cartShops.Add(basket);
                }else
                {
                  shopdb.count +=  basket.count;
                }
                 _context.SaveChanges();
          
          
        }else
        {
             product pro=await _repoproduct.getaByIdProductAsync(basket.IDProduct);
            cartShop shop=new cartShop()
            {
                product=pro,
                IDProduct=pro.Id,
            };
    
            return Ok(_mapper.Map<cartShop,cartShopDto>(shop));

        }
        return Ok();
    }
    
    // [HttpDelete]
    //     public async Task DeleteBasket(string id)
    //     {
    //         await _basket.DeleteBasketAsync(id);
    //     }
   
        // GET: api/Basket/Detailspro/2
       [HttpGet("Detailspro")]
       
        public async Task<ActionResult<cartShopDto>> Getproduct(int id)

    {
         if (id ==null)
        {
            return NotFound();
        }
            product pro=await _repoproduct.getaByIdProductAsync(id);
            cartShop shop=new cartShop()
            {
                product=pro,
                IDProduct=pro.Id,
            };
    
            return Ok(_mapper.Map<cartShop,cartShopDto>(shop));

    }
    //All Data by User in basket
//Get : api/basket/BasketProduct
 [HttpGet("BasketProduct")]
        [Authorize]
        public async Task<ActionResult<orderDetailsViewModels>> BasketProduct()
        {
          var user=await _userManager.FindByEmailFromClaimsPrinciple(HttpContext.User);
            var countUserbasket= _context.cartShops.Where(ww=>ww.UserEamil ==user.Email).ToList().AsQueryable().Count();
            if (countUserbasket !=0)
            {
                 var countUser= _context.cartShops.Where(ww=>ww.UserEamil ==user.Email).ToList();
                 
            List<cartList> listModel=new List<cartList>();
            foreach (var items in countUser)
            {
                int a=items.IDProduct;
                    var pro=await _repoproduct.getaByIdProductAsync(a);

                        listModel.Add(new cartList
                        { 
                        product=pro,
                        IDProduct=pro.Id,
                        count=items.count,
                        Id=items.Id,
                        UserEamil=items.UserEamil,
                        PriceTotal=Math.Round(Convert.ToDouble(items.count) * pro.Price,2),
                        });
            }
            return Ok(_mapper.Map<IReadOnlyList<cartList>,IReadOnlyList<orderDetailsViewModels>>(listModel));

            }
            return Ok("Sorry , your basket is empty");

           }

           //Get: api/basket/Sum
           [HttpGet("sum")]
        [Authorize]
        public async Task<ActionResult> sumList()
        {
          var user=await _userManager.FindByEmailFromClaimsPrinciple(HttpContext.User);
                 var countUser= _context.cartShops.Where(ww=>ww.UserEamil ==user.Email).ToList();
                    // cartList c=new cartList();
                    double sum=0;
                    foreach (var items in countUser)
                    {
                    int a=items.IDProduct;
                    var pro=await _repoproduct.getaByIdProductAsync(a);

                        sum +=pro.Price*items.count;
                    }
                    return Ok(Math.Round(sum,2));
        }
        // Delete : api/basket/removeItem/2
           [HttpGet("removeItem")]
        [Authorize]
        public async Task<ActionResult> remove(int id)
        {
            if(id == null)
            {
            return NotFound();
            }
            try
            {
              var shop= await _context.cartShops.FindAsync(id);
             _context.cartShops.Remove(shop);
           await _context.SaveChangesAsync();

            }
            catch (System.Exception)
            {
                
                throw;
            }
       return RedirectToAction("BasketProduct");
         
        }
                
        //function minus product 
        [HttpGet("minusItem")]
        [Authorize]
          public async Task<IActionResult> minus(int id)//id ====> from cartShop.id
        {
           var shop= await _context.cartShops.FindAsync(id);
           if(shop.count > 1){
            shop.count -=1;
           }
           await _context.SaveChangesAsync();
        // return Ok();
       return RedirectToAction("BasketProduct");
        }
        //function add product 
         [HttpGet("plusItem")]
        [Authorize]
        public async Task<IActionResult> plus(int id)//pro_id ====> from product.id
        {

           var shop= await _context.cartShops.FindAsync(id);
            shop.count +=1;
           await _context.SaveChangesAsync();
       return RedirectToAction("BasketProduct");
        } 


    }
}
