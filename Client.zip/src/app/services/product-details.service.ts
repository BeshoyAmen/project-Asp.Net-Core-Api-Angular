import { Injectable } from '@angular/core';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { RouterModule ,Routes,ActivatedRoute} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProductDetailsService {
  url = 'http://localhost:5000/api/product/';
  GallaryUrl = 'http://localhost:5000/api/ProductGallary/photoList?id='
  urlCategory='http://localhost:5000/api/product/Category';

  constructor(private http: HttpClient) { }
  getProduct(id:any)
  {
    return this.http.get(this.url+id);
  }
  getProductPictures(id:any){
    console.log(id);
    return this.http.get(this.GallaryUrl+id);
  }


  getCategory(){
    return this.http.get(this.urlCategory);
  }
}
