import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, Output } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  public cartItemList: any = [];
  public productList = new BehaviorSubject<any>([]);
  url = 'http://localhost:5000/api/Basket';
  getUrl = 'http://localhost:5000/api/Basket/BasketProduct'
  constructor(private http: HttpClient) { }
  HttpOptions={
    headers:new HttpHeaders({
      "Authorization":'Bearer '+localStorage.getItem('token')
    })
  };
// 
  getProducts(){
    return this.http.get<any>(this.getUrl,this.HttpOptions);
  }
  SummmAllProduct(){
    return this.http.get<any>(this.url+'/'+'sum',this.HttpOptions);

  }
  setProducts(product :any){
    this.cartItemList.push(...product);
    this.productList.next(product);

  }

  addtoCart(product : any){
    this.cartItemList.push(product);
    this.productList.next(this.cartItemList);
    this.getTotalPrice();
    console.log(this.cartItemList);
  }
  getTotalPrice() :number{
    let grandTotal = 0;
    this.cartItemList.map((item:any)=>{
      grandTotal += item.price;
    })
    return grandTotal;
  }

  removeCartItem(id : any){
    return this.http.get<any>(this.url+'/'+'removeItem?id='+id,this.HttpOptions);
   }
   plusItem(id : any){
     console.log(id);
    return this.http.get<any>(this.url+'/'+'plusItem?id='+id,this.HttpOptions);
   }
    mines(id : any){
    console.log(id);

    return this.http.get<any>(this.url+'/'+'minusItem?id='+id,this.HttpOptions);

   }

  getDataFromBasket(){
    return this.http.get<any>(this.getUrl,this.HttpOptions)
    .pipe(map((res:any)=>{ return res.json();}))

  }
// post(url , data )
  postBasketProducts(id:number, quantity:any){
    return this.http.post<any>(this.url,{
      idProduct:id,
      count:quantity,
    },this.HttpOptions)
    .pipe(map((res:any) =>{  console.log(res);return res;  }))
   
  }

//post to basket
postBasketProduct(data:any){
  return this.http.post<any>(this.url,data,this.HttpOptions)
  .pipe(map((res:any) =>
  {  console.log(res);return res; }))


  }
}
