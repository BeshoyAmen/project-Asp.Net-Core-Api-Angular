using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace core.Model.cart
{
    public class cartList:baseEntity
    {
         public string   UserEamil { get; set; }

         public int IDProduct { get; set; }
        [NotMapped]
        [ForeignKey("IDProduct")]
        public virtual product product {get;set;}
         public int count { get; set; }
         public double PriceTotal { get; set; }
        //  public double PriceTotalAllProduct { get; set; }
         public double Price { get; set; }

    }
}