import { AlertService } from './../../../services/services/alert.service';
import { AuthantcationService } from './../../../services/services/authantcation.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  name="";
  pass="";
  email:any;
  confirm:any;
  street:any;
  city:any;
  students:{name:string,pass:string, email:string}[]=[];
  
    constructor(private router: Router,private api:AuthantcationService,private alert:AlertService) {
      this.load();
     }
  
    ngOnInit(): void {
      this.load();
    }
    
    allData()
    {
        let student:{DisplayName:string,Password:string, email:string,Street:string,City:string} = {City:this.city,Street:this.street,DisplayName:this.name,Password:this.pass,email:this.email};
       console.log(student);
        this.api.register(student).subscribe(res=>{
          this.alert.success("success register");
        this.load();
        this.router.navigate(['']);

        },err=>{
          this.alert.error("faild register");
        })
    }
    load()
    {
      this.api.getUser();
    }
  
  }
  