﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Infrastructore.Data.Migrations
{
    public partial class intiatadlCreai6 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "basketId",
                table: "cartShops");

            migrationBuilder.CreateTable(
                name: "orderHeaders",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserEamil = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    orderDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    orderTotalOrgianl = table.Column<double>(type: "float", nullable: false),
                    orderTotal = table.Column<double>(type: "float", nullable: false),
                    pickuptime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    codeCopone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    codeCoponeDescound = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    stutes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PickName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    address = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_orderHeaders", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "orderDeatilss",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderId = table.Column<int>(type: "int", nullable: false),
                    IDProduct = table.Column<int>(type: "int", nullable: false),
                    count = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_orderDeatilss", x => x.Id);
                    table.ForeignKey(
                        name: "FK_orderDeatilss_orderHeaders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "orderHeaders",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_orderDeatilss_Products_IDProduct",
                        column: x => x.IDProduct,
                        principalTable: "Products",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_orderDeatilss_IDProduct",
                table: "orderDeatilss",
                column: "IDProduct");

            migrationBuilder.CreateIndex(
                name: "IX_orderDeatilss_OrderId",
                table: "orderDeatilss",
                column: "OrderId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "orderDeatilss");

            migrationBuilder.DropTable(
                name: "orderHeaders");

            migrationBuilder.AddColumn<Guid>(
                name: "basketId",
                table: "cartShops",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));
        }
    }
}
