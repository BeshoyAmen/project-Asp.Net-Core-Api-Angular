import { Component, ElementRef, Input, OnInit, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { CartService } from 'src/app/services/cart.service';
import { SearchService } from 'src/app/services/search.service';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {


  getdata: any;

  constructor(private searchService : SearchService,private elRef:ElementRef, private activatedRoute: ActivatedRoute, private router: Router ,private cart : CartService)
  {
    // this.searchService.listen().subscribe((m:any)=>{
    //   console.log(m);
    //   this.getSearchData();
    // })
  }

  getSearchData(){
    let searchid = this.activatedRoute.snapshot.params.id;
    this.searchService.getData(searchid).subscribe((res :any)=>{
      this.getdata = res;
      console.log(this.getdata);

     })
  }
  ngOnInit(): void {
    this.getSearchData();
  }

  increase(id:any){
    let count = this.elRef.nativeElement.querySelector('#id'+id).value;
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

    let productCo = parseInt(count);
    if(productCo >=1){

      productCo++;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();
    }else{
      productCo = 1;
      productCo++;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();

    }
    console.log(productCo);
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

  }
  decrease(id:any){
    let count = this.elRef.nativeElement.querySelector('#id'+id).value;
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

    let productCo = parseInt(count);
    if(productCo >=1){

      productCo--;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();
    }else{
      productCo = 1;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();

    }
    console.log(productCo);
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

  }
  AddToCart(id:any){
    this.cart.addtoCart(id);
    let count = this.elRef.nativeElement.querySelector('#id'+id).value;
    this.cart.postBasketProducts(id,count).subscribe(res =>{ console.log(res); return  res})
  }
}