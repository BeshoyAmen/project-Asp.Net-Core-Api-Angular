using System.Reflection.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Infrastructore.Data;
using core.Model;
using System.Security.Claims;
using Microsoft.AspNetCore.Identity;
using core.Model.Identity;
using Api.Dtos;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using core.interfaces;
using Api.Extensions;
using Infrastructore.Data.Identity;
namespace Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        		private readonly UserManager<IdentityUser> userManager2;

        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;
        private readonly ItokenServices _tokenServices;
        private readonly IMapper _mapper;
        
        public AccountController(dataContext context,
        UserManager<AppUser> userManager,
         SignInManager<AppUser> signInManager,
         ItokenServices tokenServices,IMapper mapper)
        {
            _userManager=userManager;
            _signInManager=signInManager;
            _tokenServices=tokenServices;
            _mapper=mapper;
            // userManager2=_userManager2;
        }
        // Post: api/Account/login
         [HttpPost("login")]
            public async Task<ActionResult<UserDto>> Login(LoginDto loginDto)
            {
                var user = await _userManager.FindByEmailAsync(loginDto.Email);

                    if (user == null) return NotFound();

                    var result = await _signInManager.CheckPasswordSignInAsync(user, loginDto.Password, false);

                    if (!result.Succeeded) return BadRequest("sorry, can not arrive account ");
                    return new UserDto
                    {
                        Email = user.Email,
                        Token = _tokenServices.CreateToken(user),
                        DisplayName = user.DisplayName
                    };
            }
           // Post: api/Account/register
           
            [HttpPost("register")]
         public async Task<ActionResult<UserDto>> Register(RegisterDto registerDto)
            {
                if (CheckEamilExist(registerDto.Email).Result.Value)
                {
                    return BadRequest("Sorry , this Address is in Use");
                }
                var user=new AppUser
                {
                    DisplayName=registerDto.DisplayName,
                    Email=registerDto.Email,
                    UserName=registerDto.Email,
                    Street=registerDto.Street,
                    City=registerDto.City
                };
                var result= await _userManager.CreateAsync(user,registerDto.Password);
                 if (!result.Succeeded) return BadRequest("invaild ");

                return new UserDto
                    {
                        Email = user.Email,
                        Token = _tokenServices.CreateToken(user),
                        DisplayName = user.DisplayName
                    };
            }
            //get current user 
           // get: api/Account/User
        [HttpGet]
        [Authorize]
        public async Task<ActionResult<UserDto>> GetCrrentUser()
        {
           try
           {
                // var email=HttpContext.User?.Claims?.FirstOrDefault(x=>x.Type==ClaimTypes.Email)?.Value;
            // var user=await _userManager.FindByEmailAsync(email);
            var user=await _userManager.FindByEmailFromClaimsPrinciple(HttpContext.User);

           return new UserDto
                    {
                        Email = user.Email,
                        Token = _tokenServices.CreateToken(user),
                        DisplayName = user.DisplayName
                        
                };
                         
           }
           catch (System.Exception)
           {
               
               throw;
           }
        }
        //this function check email exist or no
        // get: api/Account/EmailExist?email=#
        [HttpGet("EmailExist")]
        public async Task<ActionResult<bool>> CheckEamilExist(string email)
        {
            return await _userManager.FindByEmailAsync(email) != null;
        }
        // get: api/Account/Address
        // [HttpGet("Address")]
        // public async Task<ActionResult<AddressDto>> GetUserAddress()
        // {
        //     var email=HttpContext.User?.Claims?.FirstOrDefault(x=>x.Type==ClaimTypes.Email)?.Value;
        //     var user=await _userManager.FindByEmailWithAddressAsync(HttpContext.User);
        //     return _mapper.Map<AddressDto>(user.Address);

        //     // return Ok(user.Address);
        // }
        [Authorize]
        [HttpPut("address")]
        public async Task<ActionResult<UserDto>> UpdateUserr(RegisterDto registerDto)
        {
            var user=await _userManager.FindByEmailWithAddressAsync(HttpContext.User);
            // user.Address=_mapper.Map<AddressDto,Address>(address);
                    user.DisplayName=registerDto.DisplayName;
                    user.Email=registerDto.Email;
                    user.UserName=registerDto.Email;
                    user.Street=registerDto.Street;
                    user.City=registerDto.City;
                    user.State=registerDto.State;
                    user.NumberHouse=registerDto.NumberHouse;
             var result=await _userManager.UpdateAsync(user);
             if (result.Succeeded)
             {
                  return new UserDto
                    {
                        Email = user.Email,
                        Token = _tokenServices.CreateToken(user),
                        DisplayName = user.DisplayName,
                        Street=user.Street,
                        City=user.City,
                        NumberHouse=user.NumberHouse,
                        State=user.State,

                    };
             }
            return BadRequest("Problem updating the user");

        }

 [HttpGet("user")]
        // get: api/Account/user

        public async Task<IActionResult> userCurent()
    {
        // var userId =  userManager2..FindFirstValue(ClaimTypes.NameIdentifier); // will give the user's userId
        var userName =  User.FindFirstValue(ClaimTypes.Name); // will give the user's userName
  var email= HttpContext.User?.Claims?.FirstOrDefault(ww=>ww.Type == ClaimTypes.Email)?.Value;
          
        // ApplicationUser applicationUser = await _userManager.GetUserAsync(User);
        // string userEmail = applicationUser?.Email; // will give the user's Email
        return Ok();
    }
    }
}
