﻿using System;

namespace core
{
    public class Class1
    {
    }
}
