import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moll',
  templateUrl: './moll.component.html',
  styleUrls: ['./moll.component.css']
})
export class MollComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
