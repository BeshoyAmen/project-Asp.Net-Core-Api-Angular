import { MailServicesService } from './../mail-services.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/services/services/alert.service';

@Component({
  selector: 'app-mail',
  templateUrl: './mail.component.html',
  styleUrls: ['./mail.component.css']
})
export class MailComponent implements OnInit {

  name : string="";
  email: string="";
  message: string="";
  Subject:string="test";

  constructor(private api:MailServicesService,private router: Router,private alert:AlertService) { }

  ngOnInit(): void {
  }
  processForm() {
    const allInfo = `My name is ${this.name}. My email is ${this.email}. My message is ${this.message}`;
    // alert(allInfo); 
    let Mail:{Name:string,Email:string,Message:string,Subject:string}={Name:this.name,Email:this.email,Message:this.message,Subject:this.Subject}
   
    this.api.getMail(Mail);
    this.alert.success("Success Send Message");
    this.router.navigate(['']);

  }
}


