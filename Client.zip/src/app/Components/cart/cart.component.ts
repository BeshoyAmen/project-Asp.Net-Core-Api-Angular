import { AlertService } from 'src/app/services/services/alert.service';
import { Component, ElementRef, OnInit } from '@angular/core';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  public products :any = [];
  public grandTotal !:number;
  public productCount :number = 1;
  constructor( private cart : CartService , private elRef:ElementRef,private alert:AlertService ) { }

  ngOnInit(): void {
    this.getProductsToCart();
    this.getSumAllProduct();
    console.log(this.products.length);
    this.invokeStripe();
  }

  getProductsToCart(){
    this.cart.getProducts().subscribe(res =>{
      this.products = res;
      // this.grandTotal = this.cart.getTotalPrice();
    })
  }
  removeItem(data :any){
    console.log(data);
    this.cart.removeCartItem(data).subscribe(res=>{
      this.products = res;
      this.getSumAllProduct();
      this.alert.warning("success remove product");
    },err=>{
      this.alert.error("faild remove product");
    });

  }
  decrease(id:any)
  {
    this.cart.mines(id).subscribe(res=>{
      this.products = res;
      this.getSumAllProduct();
      this.alert.success("success plus this product");
    },err=>{
      this.alert.error("please try again");
    })
  }
  increase(id:any)
  {
    this.cart.plusItem(id).subscribe(res=>{
      this.products = res;
      this.getSumAllProduct();
      this.alert.success("success increase this product");
    },err=>{
      this.alert.error("please try again");
    })
  }
getSumAllProduct()
{
  this.cart.SummmAllProduct().subscribe(res=>{
    this.grandTotal=res;
    this.getProductsToCart();
    console.log("success");
  },err=>{
    console.log("err");
  })
}
  //Payment 
  makePayment(amount:any)
{
  //StripeCheckout
  const paymentHandler=(<any>window).StripeCheckout.configure(
    {
      key:'pk_test_51JHtA1FTgVzsT8XMz7bgyvx0VAWkj57Wf6VEgyHP3NV7JeueVfUCqCmbHMig8H41jgORJWatBwoEQsxlB07iOPaC00jC35Riz5',
      token: function(stripeToken:any)
      {
        console.log(stripeToken.card);
        alert('stripe token generated!');
      }
    });
    paymentHandler.open({

      name:'Stripe Payment',
      // description:'',
      // amount: amount*100,
    });
}
invokeStripe()
{
   if(!window.document.getElementById('stripe-script'))
   {
     const script= window.document.createElement('script');
     script.id='stripe-script';
     script.type='text/javascript';
     script.src="https://checkout.stripe.com/checkout.js";
     window.document.body.appendChild(script);

   }
}

}
