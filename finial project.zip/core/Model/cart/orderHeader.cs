using System.ComponentModel.DataAnnotations;
using System;
namespace core.Model.cart
{
    public class orderHeader:baseEntity
    {
        [Required]
        public String   UserEamil { get; set; }
        public DateTime orderDate { get; set; }
        public double orderTotalOrgianl { get; set; }
        public double orderTotal { get; set; }

        public DateTime pickuptime { get; set; }
        
        public String codeCopone { get; set; }
        public String codeCoponeDescound { get; set; }
        public String stutes { get; set; }
        public String comment { get; set; }
        [Required]
        public String PickName { get; set; }
        [Required]
        public String PhoneNumber { get; set; }
        [Required]
        public String address { get; set; }
        
    }
}