using AutoMapper;
using core.Model;
using core.Model.cart;
using Api.Dtos;
using core.Model.Identity;
using Api.DtoCartViewModel;

namespace Api.Helper
{
    public class MappingProfiles:Profile
    {
        public MappingProfiles()
        {
            CreateMap<product, ProductToReturnDto>()
            .ForMember(d=>d.ProductBrand,o=>o.MapFrom(p=>p.productbrand.Name))
            .ForMember(d=>d.ProductBrandID,o=>o.MapFrom(p=>p.productbrand.Id))
            .ForMember(d=>d.ProductType,o=>o.MapFrom(p=>p.productype.Name))
            .ForMember(d=>d.ProductTypeID,o=>o.MapFrom(p=>p.productype.Id))
            .ForMember(d=>d.PictureUrl,o=>o.MapFrom<productUrlMapper>());




              CreateMap<cartShop, cartShopDto>()
            .ForMember(d=>d.ProductBrand,o=>o.MapFrom(p=>p.product.productbrand.Name))
            .ForMember(d=>d.ProductType,o=>o.MapFrom(p=>p.product.productype.Name))
            .ForMember(d=>d.descripation,o=>o.MapFrom(p=>p.product.Description))
            .ForMember(d=>d.Price,o=>o.MapFrom(p=>p.product.Price))
            .ForMember(d=>d.PictureUrl,o=>o.MapFrom<productToShopUrlMapper>());



              CreateMap<cartList, orderDetailsViewModels>()
            .ForMember(d=>d.ProductBrand,o=>o.MapFrom(p=>p.product.productbrand.Name))
            .ForMember(d=>d.ProductType,o=>o.MapFrom(p=>p.product.productype.Name))
            .ForMember(d=>d.descripation,o=>o.MapFrom(p=>p.product.Description))
            .ForMember(d=>d.Price,o=>o.MapFrom(p=>p.product.Price))
            .ForMember(d=>d.Name,o=>o.MapFrom(p=>p.product.Name))
            .ForMember(d=>d.PictureUrl,o=>o.MapFrom<productToShopbasketUrlMapper>());


            CreateMap<productbrand, prandCategory>();

            CreateMap<core.Model.Identity.Address,AddressDto>().ReverseMap();

            CreateMap<AddressDto,core.Model.OrderCheckOut.Address>();
        }
    }
}