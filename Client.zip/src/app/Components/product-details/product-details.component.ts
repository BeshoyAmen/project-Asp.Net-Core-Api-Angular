import { Iproduct } from './../../datatype/iproduct';
import { Component, ElementRef, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CartService } from 'src/app/services/cart.service';
import { ProductDetailsService } from 'src/app/services/product-details.service';
import { AlertService } from 'src/app/services/services/alert.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  productDetails:any;
  productPictures:any;
  // getPicture:any;
  constructor(private router:Router,private alert:AlertService,private elRef:ElementRef,private productService : ProductDetailsService, private activatedRoute: ActivatedRoute, private cart : CartService)
   {

   }

  ngOnInit(): void {
    let productid = this.activatedRoute.snapshot.params.id;
    // console.log(productid);
    this.productService.getProduct(productid).subscribe((res :any)=>{
     this.productDetails= res;
     console.log(res)
    //  console.log(this.productDetails);
    })


    this.productService.getProductPictures(productid).subscribe((res)=>{
      this.productPictures= res;
      console.log(this.productPictures);
     })

  }
  count:any;
  AddToCart(id:any){
    this.cart.addtoCart(id);
    console.log(this.count);
    console.log(id);
    let token=localStorage.getItem('token');
    if(token != null){
    let data:{idProduct:number,count:number}={count:this.count,idProduct:id};
  
    this.cart.postBasketProduct(data).subscribe(res =>{
       console.log(res)
       this.alert.success("success add this product in your basket");
    this.router.navigate(['']);
      ; return  res},
      err=>{
       this.alert.error("faild add this product in your basket");
      })
    }else{
    this.router.navigate(['login']);

    }
  }

  increase(id:any){
    let count = this.elRef.nativeElement.querySelector('#id'+id).value;
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

    let productCo = parseInt(count);
    if(productCo >=1){

      productCo++;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();
    }else{
      productCo = 1;
      productCo++;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();

    }
    console.log(productCo);
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

  }
  decrease(id:any){
    let count = this.elRef.nativeElement.querySelector('#id'+id).value;
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

    let productCo = parseInt(count);
    if(productCo >=1){

      productCo--;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();
    }else{
      productCo = 1;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();

    }
    console.log(productCo);
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

  }

}