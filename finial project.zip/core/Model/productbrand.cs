using System.Collections.Generic;

namespace core.Model
        //cat
{
    public class productbrand:baseEntity
    {

        public string Name { get; set; }

        //  public virtual ICollection<product> product { get; set; }
        // =new HashSet<product>();
        
    }
}