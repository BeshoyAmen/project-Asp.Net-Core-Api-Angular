using AutoMapper;
using core.Model;
using core.Model.cart;
using Api.Dtos;
using Microsoft.Extensions.Configuration;

namespace Api.Helper
{
    public class productToShopUrlMapper:IValueResolver<cartShop,cartShopDto,string>
    {
        
        private readonly IConfiguration _config;
        public productToShopUrlMapper(IConfiguration config)
        {
            _config = config;
        }

        public string Resolve(cartShop source, cartShopDto destination, string destMember, ResolutionContext context)
        {
            if (!string.IsNullOrEmpty(source.product.PictureUrl)) 
            {
                return _config["ApiURl"] + source.product.PictureUrl;
            }
            return null;
        }   

    }
}