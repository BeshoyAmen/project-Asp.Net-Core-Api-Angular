import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/services/services/alert.service';
import { AuthantcationService } from 'src/app/services/services/authantcation.service';
import { User } from 'New folder (2)/src/app/Components/Account/model/user';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  
  name="";
  pass="";
  email:any;
  confirm:any;
  street:any;
  city:any;
  students:{name:string,pass:string, email:string}[]=[];

  constructor(private router: Router,private api:AuthantcationService,private alert:AlertService) { }

  ngOnInit(): void {
    this.load();
      }

      load(){
        this.api.getUser().subscribe((user:User)=>{
          let token=localStorage.getItem('token');
        if(token != null){
          this.name=user.displayName;
          this.email=user.email;
          this.street=user.Street;
          this.city=user.City;
        }
            // this.router.navigate(['']);
            },err=>{
            // this.alert.error(err);
        
            })
          }
          allData()
          {
            
          }
}
