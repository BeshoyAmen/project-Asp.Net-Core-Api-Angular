import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/services/services/alert.service';
import { AuthantcationService } from 'src/app/services/services/authantcation.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email="";
  pass="";
  ues:{name:string,pass:string, email:string}[]=[];
  
    constructor(private api:AuthantcationService,private alert:AlertService,private router: Router) 
    {
      this.load();
     }
  
    ngOnInit(): void {
      this.load();
    }
  
    allData()
    {
      let student:{Password:string, email:string} = {Password:this.pass,email:this.email};
      console.log(student);
        this.api.login(student).subscribe(res=>{
          this.alert.success("user Login");
        this.load();
    this.router.navigate(['']);
          
        },err=>{
          this.alert.error("faild Login");
        });
    }
    load()
    {
      this.api.getUser();
    }
  
  }
  // Pa$$w0rd
  