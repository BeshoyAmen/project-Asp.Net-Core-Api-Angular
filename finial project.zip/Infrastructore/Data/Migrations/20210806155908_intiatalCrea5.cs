﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Infrastructore.Data.Migrations
{
    public partial class intiatalCrea5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ShipToAddress_ZipCode",
                table: "Orders",
                newName: "ShipToAddress_NumberHouse");

            migrationBuilder.CreateTable(
                name: "cartShops",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserEamil = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IDProduct = table.Column<int>(type: "int", nullable: false),
                    count = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cartShops", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "cartShops");

            migrationBuilder.RenameColumn(
                name: "ShipToAddress_NumberHouse",
                table: "Orders",
                newName: "ShipToAddress_ZipCode");
        }
    }
}
