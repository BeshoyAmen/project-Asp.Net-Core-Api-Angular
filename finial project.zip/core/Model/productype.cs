using System.Collections.Generic;

namespace core.Model
{

    //sub
    public class productype:baseEntity
    {
        public string Name { get; set; }

        // public virtual ICollection<product> product { get; set; }
        // =new HashSet<product>();
        
        
        
    }
}