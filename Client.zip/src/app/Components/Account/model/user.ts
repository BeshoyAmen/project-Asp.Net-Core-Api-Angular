export interface User
{
    email:string;
    displayName:string;
    token:string;
    Street :string;
    City :string;
    State:string;
    NumberHouse:string;
}
