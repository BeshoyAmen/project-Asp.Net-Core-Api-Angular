import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MollComponent } from './moll.component';

describe('MollComponent', () => {
  let component: MollComponent;
  let fixture: ComponentFixture<MollComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MollComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MollComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
