import { AlertService } from './../../services/services/alert.service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MailServicesService {
  url="http://localhost:5000/api/Contact";
  constructor(private Http:HttpClient,private alert:AlertService) { }
  getMail(Mail:any)
  {
    console.log(Mail);
    return this.Http.post(this.url,Mail).subscribe(res=>{
      this.alert.success("تم ايصال الرسالة بنجاح");
    });
  }
}