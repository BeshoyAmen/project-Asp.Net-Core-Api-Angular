import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { map } from 'jquery';
import { Subject } from 'rxjs';
import { CartService } from 'src/app/services/cart.service';
import { CategoryService } from 'src/app/services/category.service';
import { DashproductserviceService } from 'src/app/services/productdashservice/dashproductservice.service';
// import {map} from 'rxjs/operators';
import { AlertService } from 'src/app/services/services/alert.service';


@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  //declartion variable
  categoryList:any;
  CategoryListWithId:any;
  products:any;
  selectedItems:string[]=[];

  //variable to recieve name of category from home page
  categoryNameComeFromHeader:any;
  @ViewChild('firstCategoryName') firstCategoryName:any;

  //to put name in select when page load based on name that clicked on it from home
  ngAfterViewInit(): void {
  
    
    
  }

  //variable to get name of category from header found in header
   headerName:any;
  constructor(private myservice:CategoryService,
    private myserviceproduct:DashproductserviceService ,
    private cart : CartService,
    private activatedRoute: ActivatedRoute,
    private router:Router,
    private alert:AlertService) {
    this.fillSelectItem();
    this.categoryselected=this.activatedRoute.snapshot.url.splice(2);
    // this.myservice.listen().subscribe((m:any)=>{
    //   console.log(m);
    //   this.fetchdataproduct(this.headerName);
    // })
    
    
    
   }

  ngOnInit(): void {
    this.getFromUrl();
    //to get id from url
    this.headerName=this.activatedRoute.snapshot.params['id'];
    this.myservice.caategoryName=this.categoryNameComeFromHeader;
    //alert(this.activatedRoute.snapshot.params['id']+"oninit");
    this.fetchdataproduct(this.headerName);
   
  }
  // @Input() totalItem :any;

  AddToCart(id:any){
    this.cart.addtoCart(id);
    // console.log(this.count);
    console.log(id);
    let token=localStorage.getItem('token');
if(token != null){
    let data:{idProduct:number,count:number}={count:1,idProduct:id};
      this.cart.postBasketProduct(data).subscribe(res =>{
      console.log(res)
      this.alert.success("success add this product in your basket")},
     
      err=>{
      this.alert.error("faild add this product in your basket");
     })
    }else{
    this.router.navigate(['login']);
    }
  }
  //get  category name from url
  getFromUrl(){
    let categoryName = this.activatedRoute.snapshot.params.id;
    this.myserviceproduct.GetAllProductsWithOutPagination().subscribe((res:any)=>{
      res.map((res:any )=> {
        if(res.productBrand == categoryName){
          this.products = res;
          console.log(res);
          return res;
        }
      })
    })
    this.selectedItems = new Array<string>();
  }

 //fillselect
 fillSelectItem(){
  this.myservice.GetAllCategory().subscribe(
    (result)=>{
      this.categoryList=result;
      console.log(this.categoryList);
    },
    (err)=>{
      console.log(err);
    }
     )

}

//product
fetchdataproduct(id:any){
   
     return this.myserviceproduct.GetAllProductsByProductBrandId(id).subscribe(
      (result)=>{
        this.products=result;
        //console.log(this.products)
       },
  
      (err)=>{console.log(err)}
    )
  
  
  
}


/****selected */
/**********select */
categoryselected:any=1;//default value
categories:any[]=[];

modifiedText:string="";
categoryNamelistusingID:any;
//select
onCategorySelected(val:any){

  
  //web api
this.newProducts=[];
this.check='false'
this.customFunction(val);
this.myservice.GetCategoryById(val).subscribe(
  (result)=>{this.categoryNamelistusingID=result},
  (err)=>{console.log(err)}
);

// var params=this.activatedRoute.snapshot.url.splice(1)

this.myserviceproduct.GetAllProductsByProductBrandId(this.modifiedText).subscribe(
(data)=>{(this.products=data),this.router.navigateByUrl(
  '/category/'+val)},
(err)=>console.log(err));

this.router.navigateByUrl('/category/'+val);
}



customFunction(val:any){

  //to get option value=category selected id
  this.modifiedText=val;
  //this.modifiedText=$event.target.options[$event.target.options.selectedIndex].text;
}


// AddToCart(data:any){
//   console.log(data);
//   this.cart.addtoCart(data)
// }

///function for checkbox
categoryid:any=[];
check:any="true";
sasa:any[]=[];
newProducts:any[]=[];

categoryOnChange(e:any ){
  this.check="true" 
  this.products=[];
  
 
  if(e.target.checked){
   // this.getProductUsingInput();

    //get all product based on brand id
    this.myserviceproduct.GetAllProductsByProductBrandId(e.target.attributes.value.nodeValue).subscribe(
     (res)=>{
       this.tempArr=res,//category id contain array of one checked
      
      //console.log(this.tempArr),
      this.newArr.push(this.tempArr)
      
      for(let i=0;i<this.newArr.length;i++){
         var firstArray=this.newArr[i];
         for(let i=0;i<firstArray.length;i++){
           var obj=firstArray[i];
          
           this.newProducts.push(obj);
           console.log(this.newProducts);
           obj=[];
         }//inner for
        
      }//outer for
      
   } );//promise

  this.categoryselected=0;
  console.log(this.newProducts+"unchecked");

   }//end if
   else{
    // this.check=false;
     this.newProducts=[];
     

   }//promise
  
}

// هبد
productArr:any[]= [];
Arrays:any[]=[];

getProductUsingInput(){
 this.productArr.push(this.myserviceproduct.GetAllProductsWithOutPagination());
 this.Arrays.push(this.myserviceproduct.GetAllProductsWithOutPagination());//all product
//alert(this.Arrays)
}
tempArr :any= [];
newArr:any=[];
x:any;

/****************************************** */
onChange(e:any){
   this.Arrays=[];
  
   if(e.target.checked){
    this.x=e.target.attributes.value.nodeValue;
    //console.log(this.x)
    //this.getProductUsingInput();
    
    this.myserviceproduct.GetAllProductsUsingCategoryName(e.target.attributes.name.nodeValue,e.target.attributes.value.nodeValue)
    .subscribe((res)=>{this.Arrays.push(res),
      console.log(this.Arrays),
      this.tempArr.push(res)
     
    },
    (err)=>{console.log(err)})
    console.log(this.tempArr)
    this.productArr=[];
    this.newArr.push(this.tempArr);
    for(let i=0;i<this.newArr.length;i++){
      var firstArray=this.newArr[i];
      for(let i=0;i<firstArray.length;i++){
        var obj=firstArray[i];
        this.productArr.push(obj);
       
      }
      //this.products=this.productArr.filter((e)=>e.productBrandId=e.target.value)
      console.log(this.newArr);
     
    }
    
   }else{
    this.tempArr=this.Arrays.filter((e)=>e.productBrandId!=this.x);
    this.newArr=[];
    this.Arrays=[];
    this.newArr.push(this.tempArr);
    console.log(this.tempArr);
   }
    
    //get all product based on brand id
    
     
   
  
    
  }
  // categoryOnChange($event)
}
