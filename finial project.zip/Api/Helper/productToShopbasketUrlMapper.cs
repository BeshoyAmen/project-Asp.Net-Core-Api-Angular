using AutoMapper;
using core.Model;
using core.Model.cart;
using Api.DtoCartViewModel;
using Microsoft.Extensions.Configuration;

namespace Api.Helper
{
    public class productToShopbasketUrlMapper:IValueResolver<cartList,orderDetailsViewModels,string>
    {
        
        private readonly IConfiguration _config;
        public productToShopbasketUrlMapper(IConfiguration config)
        {
            _config = config;
        }

        public string Resolve(cartList source, orderDetailsViewModels destination, string destMember, ResolutionContext context)
        {
            if (!string.IsNullOrEmpty(source.product.PictureUrl)) 
            {
                return _config["ApiURl"] + source.product.PictureUrl;
            }
            return null;
        }   

    }
}