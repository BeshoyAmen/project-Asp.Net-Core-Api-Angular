namespace core.Model
{
    public class gallaryModel:baseEntity
    {
        public string Name { get; set; }
        public string Url { get; set; }
    }
}