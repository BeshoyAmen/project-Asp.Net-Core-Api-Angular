import { Component, OnInit ,AfterViewInit, Input, ElementRef} from '@angular/core';
import { CartService } from 'src/app/services/cart.service';
import { LandingPageService } from 'src/app/services/landing-page.service';
import { AlertService } from 'src/app/services/services/alert.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css']
})
export class LandingPageComponent implements OnInit {

  products:any;
  categories:any;
  getproductPicture:any;
  num:number = 2;
  productPicture:string ='';
  @Input()  productCount: number =1 ;
  constructor(private router: Router,private alert:AlertService,private productsService : LandingPageService , private cart : CartService,private elRef:ElementRef) {

   }


  ngOnInit(): void {
    this.productsService.getProducts().subscribe((res)=>{
     this.products= res;
     console.log(this.products);
    })
    this.productsService.getCategory().subscribe((res)=>{
      this.categories = res;
      console.log(this.categories);
    })
    this.productsService.getPicture(this.productPicture).subscribe((res)=>{
      this.getproductPicture = res;
      console.log(this.getproductPicture);
    })
  }
// count:any;
// post data to cart
  AddToCart(id:any){
    this.cart.addtoCart(id);
    // console.log(this.count);
    console.log(id);
    let token=localStorage.getItem('token');
if(token != null){
    let data:{idProduct:number,count:number}={count:1,idProduct:id};
      this.cart.postBasketProduct(data).subscribe(res =>{
      console.log(res)
      this.alert.success("success add this product in your basket");
     ; return  res},err=>{
      this.alert.error("faild add this product in your basket");
     })
    }else{
    this.router.navigate(['login']);
    }
  }

  increase(id:any){
    let count = this.elRef.nativeElement.querySelector('#id'+id).value;
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

    let productCo = parseInt(count);
    if(productCo >=1){

      productCo++;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();
    }else{
      productCo = 1;
      productCo++;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();

    }
    console.log(productCo);
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

  }
  decrease(id:any){
    let count = this.elRef.nativeElement.querySelector('#id'+id).value;
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

    let productCo = parseInt(count);
    if(productCo >=1){

      productCo--;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();
    }else{
      productCo = 1;
      this.elRef.nativeElement.querySelector('#id'+id).value = productCo.toString();

    }
    console.log(productCo);
    console.log(this.elRef.nativeElement.querySelector('#id'+id));

  }
  ngAfterViewInit(){
    setTimeout(function () {

    (<any>$('.owl-carousel')).owlCarousel({
      dots: true,
      autoplay: true,
      loop: true,
      margin: 5,
      nav: false,
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 3
        },
        1000: {
          items: 4
        }
    }
  })
}, 2500);
}

}