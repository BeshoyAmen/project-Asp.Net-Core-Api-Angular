namespace Api.DtoCartViewModel
{
    public class orderDetailsViewModels
    {
        
        public double Price { get; set; }
        public string Name { get; set; }
        public string Id { get; set; }
        public string   UserEamil { get; set; }
        public string ProductBrand { get; set; }
        public string ProductType { get; set; }
        public string descripation { get; set; }
        public string PictureUrl { get; set; }
        public int IDProduct { get; set; }
        public int count { get; set; }
        public double PriceTotal { get; set; }
        //  public double PriceTotalAllProduct { get; set; }

    }
}