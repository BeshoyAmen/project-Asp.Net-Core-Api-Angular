using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace core.Model.cart
{
    public class cartShop:baseEntity
    {
        public cartShop()
        {
            count=1;
        }
        public String   UserEamil { get; set; }

         public int IDProduct { get; set; }
        [NotMapped]
        [ForeignKey("IDProduct")]
        public virtual product product {get;set;}
         public int count { get; set; }
        [NotMapped]
         public int Price { get; set; }

    }
}