using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;
namespace core.Model.cart
{
    public class orderDeatils:baseEntity
    {
        public int OrderId { get; set; }
        [ForeignKey("OrderId")]

        public virtual orderHeader orderHeader { get; set; }

       public int IDProduct { get; set; }
        [ForeignKey("IDProduct")]
        public virtual product product {get;set;}

        public int count { get; set; }

    }
}