using System.Security.Claims;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Infrastructore.Data;
using Api.Dtos;
using Api.Extensions;
using Api.DtoCartViewModel;
using AutoMapper;
using core.interfaces;
using core.Model.cart;

namespace Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        // private readonly UserManager<AppUser> _userManager;

        private readonly dataContext _context;
        private readonly IOrderServices repoOrdre;
        private readonly IMapper maper;
        public OrdersController(dataContext context,IOrderServices _repoOrdre, IMapper _maper)
        {
            // _userManager=userManager;
            maper = _maper;
            repoOrdre = _repoOrdre;
            _context=context;
        }

        [BindProperty]
        public orderDetailsViewModels orderDetailsViewModelsMV { get; set; }

       // api/Orders/pro
    //    [httpGet]
    //    public async Task<IActionResult> Indes()
    //    {
    //        orderDetailsViewModelsMV=new orderDetailsViewModels()
    //        {
    //            orderHeader=new orderHeader()
    //        };
    //           orderDetailsViewModelsMV.orderHeader.orderTotal=0;
    //       var user=await _userManager.FindByEmailFromClaimsPrinciple(HttpContext.User);
    //         var shopingCart=_context.cartShops.Where(x=>x.UserEamil ==user.Email);

    //         if(shopingCart != null)
    //         {
    //                 orderDetailsViewModelsMV.shopingCartList=shopingCart.ToList();
    //         }
    //         foreach (var item in orderDetailsViewModelsMV.shopingCartList)
    //         {
    //             item.product=_context.Products.FirstOrDefault(p=>p.Id==item.IDProduct);
    //             orderDetailsViewModelsMV.orderHeader.orderTotal +=item.product.Price * item.count;
    //             orderDetailsViewModelsMV.orderHeader.orderTotal=Math.Round(orderDetailsViewModelsMV.orderHeader.orderTotal,2);
    //         }
    //         orderDetailsViewModelsMV.orderHeader.orderTotalOrgianl=orderDetailsViewModelsMV.orderHeader.orderTotal;

    //         return Ok(orderDetailsViewModelsMV);
    //    }
    // [httpGet]
    //    public async Task<IActionResult> Indes()
    //    {

    //    }

    }
}