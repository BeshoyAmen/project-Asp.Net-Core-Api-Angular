using System;

namespace core.Model.cart
{
    public class StoreId
    {
        public Guid Id {get;set;}
        public int count {get;set;}
        public string UserEmail {get;set;}
    }
}