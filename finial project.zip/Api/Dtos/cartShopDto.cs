using System;

namespace Api.Dtos
{
    public class cartShopDto
    {
        public string Id { get; set; }
        public string   UserEamil { get; set; }
        public string ProductBrand { get; set; }
        public string ProductType { get; set; }
        public string descripation { get; set; }
        public string PictureUrl { get; set; }
        public Double Price { get; set; }
        public int count { get; set; }
        public int IDProduct { get; set; }

    }
}