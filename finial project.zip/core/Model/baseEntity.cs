using System.ComponentModel.DataAnnotations;

namespace core.Model
{
    public class baseEntity
    {
        [Key]
        public int Id { get; set; }
        
    }
}