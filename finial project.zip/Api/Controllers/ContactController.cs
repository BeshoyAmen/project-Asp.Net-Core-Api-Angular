using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net.Mail;
using Api.Dtos;

namespace Api.Controllers
{
     [Route("api/[controller]")]
    [ApiController]
    public class ContactController:ControllerBase
    {
        
        // POST: api/Contact
        [HttpPost]
        public IActionResult contact(ContactViewModel vm)
        {

            //if (ModelState.IsValid)
            //{
                try
                {
                    MailMessage msz = new MailMessage();
                    msz.From = new MailAddress(vm.Email);//Email which you are getting 
                                                         //from contact us page 
                    msz.To.Add("eslammuhammed766@gmail.com");//Where mail will be sent 
                    msz.Subject = vm.Subject;
                    msz.Body = vm.Message;
                    SmtpClient smtp = new SmtpClient();

                    smtp.Host = "smtp.gmail.com";

                    smtp.Port = 587;

                    smtp.Credentials = new System.Net.NetworkCredential
                    ("eslammuhammed766@gmail.com", "Group2@iti");

                    smtp.EnableSsl = true;

                    smtp.Send(msz);

                    ModelState.Clear();
                    return Ok("Thank you for Contacting us ");
                }
                catch (Exception ex)
                {
                    ModelState.Clear();
                    return BadRequest(" Sorry we are facing Problem here");
                }
            //}

            return Ok();
        }


    }
}